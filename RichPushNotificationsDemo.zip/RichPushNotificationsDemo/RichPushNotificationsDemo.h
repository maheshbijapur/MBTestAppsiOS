//
//  RichPushNotificationsDemo.h
//  RichPushNotificationsDemo
//
//  Created by Maheshashok Bijapur on 4/22/20.
//  Copyright © 2020 Maheshashok Bijapur. All rights reserved.
//

#ifndef RichPushNotificationsDemo_h
#define RichPushNotificationsDemo_h

#import <Marketo/Marketo.h>

#endif /* RichPushNotificationsDemo_h */
