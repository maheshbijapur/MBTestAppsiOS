//
//  ResultViewController.swift
//  RichPushNotificationsDemo
//
//  Created by Maheshashok Bijapur on 4/22/20.
//  Copyright © 2020 Maheshashok Bijapur. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    var text : String = ""
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var infoLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if text == "Accepted" {
            imageView.image = UIImage(named: "Accepted.PNG")
            infoLabel.text = "ACCEPTED!!!"
        }
        else{
            imageView.image = UIImage(named: "Rejected.PNG")
            infoLabel.text = "DECLINED!"
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
