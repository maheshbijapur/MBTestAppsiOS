//
//  AppDelegate.swift
//  RichPushNotificationsDemo
//
//  Created by Maheshashok Bijapur on 4/22/20.
//  Copyright © 2020 Maheshashok Bijapur. All rights reserved.
//

import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    var testNavigationController : UINavigationController?
    var checkFlag : Bool = true
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let storyBoard : UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let vc : ViewController = storyBoard.instantiateViewController(identifier: "MainViewController")
        self.testNavigationController = UINavigationController.init(rootViewController: vc)
//        self.testNavigationController?.pushViewController(vc, animated: false)
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window?.rootViewController = testNavigationController
        self.window?.backgroundColor = UIColor.white
        self.window?.largeContentTitle = "Rich Push"
        self.window?.makeKeyAndVisible()
        
        UNUserNotificationCenter.current().delegate = self;
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {(granted, error) in
            guard granted else { return }
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
        
        let sharedInstance: Marketo = Marketo.sharedInstance()
        sharedInstance.initialize(withMunchkinID: "528-FEX-444", appSecret: "NHlKRmtoNXUxTThvSGpxUnFQSVYyZE52", launchOptions: launchOptions)
        
        let profile : MarketoLead =  MarketoLead()
         
        // Get user profile from network and populate
        profile.setEmail("sandboxleadcreationmb@makesomething.com")
        profile.setFirstName("Mahesh")
        profile.setLastName("B")
        profile.setAddress("Bengaluru")
        
        // This method will update user profileTGJxczFPTlg4cGo3ZVV1SzNBZE1ZUTI0
        sharedInstance.associateLead(profile)
        
        //NSLog(@"%@",[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory  inDomains:NSUserDomainMask] lastObject]);
        
        print("Path to data ", NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first ?? "")
        
        return true
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        print(deviceToken)
        Marketo.sharedInstance()?.registerPushDeviceToken(deviceToken)
        
        // 1. Convert device token to string
        let tokenParts = deviceToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        let token = tokenParts.joined()
        // 2. Print device token to use for PNs payloads
        print("Device Token: \(token)")
        let bundleID = Bundle.main.bundleIdentifier;
        print("Bundle ID: \(token) \(String(describing: bundleID))");
        // 3. Save the token to local storeage and post to app server to generate Push Notification. ...
        
//        setCategory()
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("failed to register for remote notifications: \(error.localizedDescription)")
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
        Marketo.sharedInstance()?.handlePushNotification(userInfo)
        
        print("Received push notification: \(userInfo)")
        print(userInfo)
        let aps = userInfo["aps"] as! [String: Any]
        print("\(aps)")
        
    }
    
    func setCategory(){
        // Define the custom actions.
//        let snoozeAction = UNNotificationAction(identifier: "snooze.action",
//                                                title: "Snooze",
//                                                options: [])

//        let pizzaCategory = UNNotificationCategory(
//            identifier: "snooze.category",
//            actions: [snoozeAction],
//            intentIdentifiers: [],
//            options: [])

        let acceptAction = UNNotificationAction(identifier: "ACCEPT_ACTION",
                                                title: "Accept",
                                                options: UNNotificationActionOptions(rawValue: 0))
        let declineAction = UNNotificationAction(identifier: "DECLINE_ACTION",
                                                 title: "Decline",
                                                 options: UNNotificationActionOptions(rawValue: 0))
        let maybeAction = UNNotificationAction(identifier: "MAY_BE",
                                               title: "May Be",
                                               options: UNNotificationActionOptions(rawValue: 0))

        let replyAction = UNTextInputNotificationAction(identifier: "REPLY_MESSAGE", title: "Reply", options: [])

        // Define the notification type
        let meetingInviteCategory =
            UNNotificationCategory(identifier: "MEETING_INVITATION",
                                   actions: [replyAction,acceptAction, declineAction, maybeAction],
                                   intentIdentifiers: [],
                                   hiddenPreviewsBodyPlaceholder: "",
                                   options: .customDismissAction)


        // Register the notification type.
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.setNotificationCategories([meetingInviteCategory])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler:
        @escaping () -> Void) {
        
        Marketo.sharedInstance()?.userNotificationCenter(center, didReceive: response, withCompletionHandler: completionHandler)
        completionHandler()
        
        // Get the meeting ID from the original notification.
//        let userInfo = response.notification.request.content.userInfo
//
//        let meetingID = userInfo["paramOne"] as? String
//        let userID = userInfo["paramTwo"] as? String
            
//        if response.notification.request.content.categoryIdentifier == "MEETING_INVITATION" {
            // Retrieve the meeting details.
//            switch response.actionIdentifier {
//            case "Google":
//                Marketo.sharedInstance()?.userNotificationCenter(center, didReceive: response, withCompletionHandler: completionHandler)
//                break
//
//            case "DECLINE_ACTION":
//                self.rejectMeeting(userId: userID!, meetingID: meetingID!)
//                break
//
//            case "MAY_BE":
//                print("May be")
//            break
//
//            case "REPLY_MESSAGE" :
//                       if let textResponse = response as? UNTextInputNotificationResponse {
//                           // Do whatever you like with user text response...
//                            print(textResponse.userText)
//                       }
//            break
//
//            case UNNotificationDefaultActionIdentifier,
//                 UNNotificationDismissActionIdentifier:
//                // Queue meeting-related notifications for later
//                //  if the user does not act.
//                //             sharedMeetingManager.queueMeetingForDelivery(user: userID,
//                //                   meetingID: meetingID)
//                print("test")
//                break
//
//            default:
//                break
//            }
//        }
//        else if response.notification.request.content.categoryIdentifier == "snooze.category"
//        {
//            // Handle other notification types...
//
//            let content = response.notification.request.content
//
//            let snoozeTrigger = UNTimeIntervalNotificationTrigger(
//                timeInterval: 25.0,
//                repeats: false)
//            let snoozeRequest = UNNotificationRequest(identifier: "snooze.category",content: content,trigger: snoozeTrigger)
//            center.add(snoozeRequest){(error) in
//                if error != nil {
//                    print("Snooze Request Error: \(String(describing: error?.localizedDescription))")
//                }
//            }
//        }
//        else{
//            print("=+++++++++++++=======================DidRecieve=+++++++++++++=======================")
//            print("response.notification.request.content.categoryIdentifier")
//
//
//             print(response.notification.request.content.categoryIdentifier)
//        }
        // Always call the completion handler when done.
        
    }
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler:
        @escaping (UNNotificationPresentationOptions) -> Void) {
        
        Marketo.sharedInstance()?.handlePushNotification(notification.request.content.userInfo)
        print(notification.request.content.userInfo)
        
        if notification.request.content.categoryIdentifier ==
            "MEETING_INVITATION" {
            // Retrieve the meeting details.
            let meetingID = notification.request.content.userInfo["paramOne"] as! String
            let userID = notification.request.content.userInfo["paramTwo"] as! String
            
            // Add the meeting to the queue.
            //          sharedMeetingManager.queueMeetingForDelivery(user: userID,
            //                meetingID: meetingID)
            if meetingID ==  "ACCEPT_ACTION"{
                self.acceptMeeting(userId: userID, meetingID: meetingID)
                
               
            }
            else{
                self.rejectMeeting(userId: userID, meetingID: meetingID)
               
            }
            
            // Play a sound to let the user know about the invitation.
            completionHandler(.sound)
            return
        }
        else if notification.request.content.categoryIdentifier == "snooze.category"{
            // Handle other notification types...
            let content =  notification.request.content// response.notification.request.content
            
            let snoozeTrigger = UNTimeIntervalNotificationTrigger(
                timeInterval: 25.0,
                repeats: false)
            let snoozeRequest = UNNotificationRequest(identifier: "snooze.category",content: content,trigger: snoozeTrigger)
            center.add(snoozeRequest){(error) in
                if error != nil {
                    print("Snooze Request Error: \(String(describing: error?.localizedDescription))")
                }
            }
        }
        else
        {
            print("=+++++++++++++=======================willPresent=+++++++++++++=======================")
            print("(notification.request.content.categoryIdentifier)")
            print(notification.request.content.categoryIdentifier)
            print(notification.request.content.body);
            
            completionHandler([.alert, .sound])
        }
        
        // Don't alert the user for other types.
        completionHandler(UNNotificationPresentationOptions(rawValue: 0))
        
        completionHandler([.alert,.sound])
    }
    
    
    func acceptMeeting(userId: String,  meetingID: String) {
        let sharedInstance = Marketo.sharedInstance()
        let mkto = MarketoActionMetaData()
        mkto?.setType("Accept Meeting")
        sharedInstance?.reportAll()
        
        print("accepted")
        print(userId,meetingID)
        let rootViewController = self.window?.rootViewController as? UINavigationController
        let storyBoard : UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let vc : ResultViewController = storyBoard.instantiateViewController(identifier: "ResultViewController")
        vc.text = "Accepted"
        rootViewController?.pushViewController(vc, animated: true)
    }
    
    
    func rejectMeeting(userId: String,  meetingID: String) {
        let sharedInstance = Marketo.sharedInstance()
        let mkto = MarketoActionMetaData()
        mkto?.setType("Reject Meeting")
        sharedInstance?.reportAction("Bought Shirt", with:mkto);
        sharedInstance?.reportAll()
        
        print("rejected")
        print(userId,meetingID)
        let rootViewController = self.window?.rootViewController as? UINavigationController
        let storyBoard : UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let vc : ResultViewController = storyBoard.instantiateViewController(identifier: "ResultViewController")
        vc.text = "Rejected"
        rootViewController?.pushViewController(vc, animated: true)
    }
}

