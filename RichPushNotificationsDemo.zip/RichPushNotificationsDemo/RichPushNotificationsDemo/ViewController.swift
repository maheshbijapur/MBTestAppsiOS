//
//  ViewController.swift
//  RichPushNotificationsDemo
//
//  Created by Maheshashok Bijapur on 4/22/20.
//  Copyright © 2020 Maheshashok Bijapur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    
    @IBAction func setCategories(_ sender: Any) {
        setMeetingCategory()
    }
    
    func setMeetingCategory(){
        // Define the custom actions.
        let acceptAction = UNNotificationAction(identifier: "ACCEPT_ACTION",
              title: "Accept",
              options: UNNotificationActionOptions(rawValue: 0))
        let declineAction = UNNotificationAction(identifier: "DECLINE_ACTION",
              title: "Decline",
              options: UNNotificationActionOptions(rawValue: 0))
        
        // Define the notification type
        let meetingInviteCategory =
              UNNotificationCategory(identifier: "MEETING_INVOTATION",
              actions: [acceptAction, declineAction],
              intentIdentifiers: [],
              hiddenPreviewsBodyPlaceholder: "",
              options: .customDismissAction)
        
        
        // Register the notification type.
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.setNotificationCategories([meetingInviteCategory])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
           didReceive response: UNNotificationResponse,
           withCompletionHandler completionHandler:
             @escaping () -> Void) {

       // Get the meeting ID from the original notification.
       let userInfo = response.notification.request.content.userInfo
       let meetingID = userInfo["MEETING_ID"] as! String
       let userID = userInfo["USER_ID"] as! String

       // Perform the task associated with the action.
       switch response.actionIdentifier {
       case "ACCEPT_ACTION":
          print("Accepted")
          self.acceptMeeting(userId: userID, meetingID: meetingID)

          break

       case "DECLINE_ACTION":
        self.rejectMeeting(userId: userID, meetingID: meetingID)
          print("Declined")
          break

       // Handle other actions…

       default:
          break
       }

       // Always call the completion handler when done.
       completionHandler()
    }
    
    func acceptMeeting(userId: String,  meetingID: String) {
        print("accepted")
        
        let alert = UIAlertController(title: "Meeting Accpted", message: "This is an alert.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
        NSLog("The \"OK\" alert occured.")
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func rejectMeeting(userId: String,  meetingID: String) {
        print("rejectMeeting")
        let alert = UIAlertController(title: "Meeting Rejected", message: "This is an alert.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
        NSLog("The \"OK\" alert occured.")
        }))
        self.present(alert, animated: true, completion: nil)
    }

}

