//
//  ViewController.swift
//  test
//
//  Created by Maheshashok Bijapur on 8/9/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .darkGray
    }

    @IBAction func associateLeadAction(_ sender: UIButton) {
        
        let marketo = Marketo.sharedInstance()
        let profile =  MarketoLead()
         
        // Get user profile from network and populate
        profile?.setEmail("aug25@mkt.com")
        profile?.setFirstName("Mahesh")
        profile?.setLastName("B")
        profile?.setCity("Bengaluru")
        marketo?.associateLead(profile)
        
    }
    
    @IBAction func customActionClicked(_ sender: UIButton) {
        
    }
    
    @IBAction func logoutAction(_ sender: Any) {
        Marketo.sharedInstance().unregisterPushDeviceToken()
    }
}

