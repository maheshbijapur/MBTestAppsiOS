//
//  AppDelegate.swift
//  test
//
//  Created by Maheshashok Bijapur on 8/9/22.
//

import UIKit
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window:UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let sharedInstance: Marketo = Marketo.sharedInstance()
        sharedInstance.initialize(withMunchkinID: "849-BHY-433", appSecret: "ZjRWbG03UTV2alVBU0x0V01CaDFyR3lk", launchOptions: launchOptions)
        
       if #available(iOS 10, *) {
           let center = UNUserNotificationCenter.current()
           center.delegate = self;
           center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
               // Enable or disable features based on authorization.
           }
       }
       else{
           application.registerUserNotificationSettings(UIUserNotificationSettings(types: [.sound, .alert, .badge], categories: nil))
       }
       application.registerForRemoteNotifications()
        
        return true
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        Marketo.sharedInstance().application(app, open: url, sourceApplication: nil, annotation: nil)
    }
    
    
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Marketo.sharedInstance().registerPushDeviceToken(deviceToken)
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        Marketo.sharedInstance().handlePushNotification(userInfo)
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return Marketo.sharedInstance().application(application, open: url, sourceApplication: nil, annotation: nil)
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("willPresent notification")
        completionHandler([.alert, .sound])  // OR
           // completionHandler(.badge) OR
            //completionHandler(.sound)
    }

    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        Marketo.sharedInstance().userNotificationCenter(center, didReceive: response, withCompletionHandler: completionHandler)
    }
}

