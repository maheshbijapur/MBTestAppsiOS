//
//  test-Bridging-Header.h
//  test
//
//  Created by Maheshashok Bijapur on 8/12/22.
//

#ifndef test_Bridging_Header_h
#define test_Bridging_Header_h

#import <Marketo/Marketo.h>

#endif /* test_Bridging_Header_h */
