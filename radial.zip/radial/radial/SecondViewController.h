//
//  SecondViewController.h
//  radial
//
//  Created by Mahesh.Bijapur on 1/14/19.
//  Copyright © 2019 Mahesh.Bijapur. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
